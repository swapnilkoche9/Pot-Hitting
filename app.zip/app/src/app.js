const startGameButton = document.getElementById("start-game");
const playArea = document.getElementById("play-area");
const statusEl = document.getElementById("status");
let clickCount = 0;
let prevDistance;
let potElement;
const potPosition = {
  xPosition: 0,
  yPosition: 0,
};

function ClickPosition(xPosition, yPosition) {
  this.xPosition = xPosition;
  this.yPosition = yPosition;
  getPosition = function () {
    return {
      xPosition: this.xPositionn,
      yPosition: this.yPosition,
    };
  };
}

startGameButton.addEventListener("click", () => {
  playArea.removeAttribute("hidden");
  startGameButton.setAttribute("hidden", true);
  addPot();
});

playArea.addEventListener("click", (e) => {
  clickCount++;
  const clickPosition = new ClickPosition(e.clientX, e.clientY);
  const distance = calculateDistance(clickPosition, potPosition);
  if (distance <= 29) {
    statusEl.innerHTML = `successfully found pot  (clicks : ${clickCount})`;
    potElement.removeAttribute("hidden");
    return;
  }
  if (clickCount > 1) {
    const status = distance < prevDistance ? "hot" : "cold";
    statusEl.innerHTML = status;
  }
  prevDistance = distance;
});

const addPot = () => {
  const playAreaX = playArea.getBoundingClientRect().x;
  const playAreaY = playArea.getBoundingClientRect().y;
  const xPosition = randomNoInRange(playAreaX, playAreaX + 600);
  const yPosition = randomNoInRange(playAreaY, playAreaY + 500);

  potElement = document.createElement("div");
  potElement.style.position = "absolute";
  potElement.style.left = xPosition + "px";
  potElement.style.top = yPosition + "px";
  potElement.setAttribute("class", "pot");
  playArea.appendChild(potElement);
  potPosition.xPosition = potElement.getBoundingClientRect().x;
  potPosition.yPosition = potElement.getBoundingClientRect().y;
  potElement.setAttribute("hidden", true);
};

const calculateDistance = (clickPosition, potPosition) => {
  const first = Math.pow(potPosition.xPosition - clickPosition.xPosition, 2);
  const second = Math.pow(potPosition.yPosition - clickPosition.yPosition, 2);
  return Math.sqrt(first + second);
};

const randomNoInRange = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1) + min);
};
